import setuptools

setuptools.setup(
    name="semseglib",
    version="0.0.1",
    author="Aturt2",
    packages=setuptools.find_packages(),
    install_requires=['numpy', 'keras', 'tensorflow']
)